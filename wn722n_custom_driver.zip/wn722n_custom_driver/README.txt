Differs from original download of this driver...
In file {DRIVER_FOLDER}/os_dep/linux/ioctl_cfg80211.c
	Removed pointer in wiphy->wowlan = &(something)

